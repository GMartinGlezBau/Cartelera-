//
//  TerceraViewController.swift
//  Cine_Proyecto
//
//  Created by 2020-1 on 10/10/19.
//  Copyright © 2019 Diego Fonseca Medina . All rights reserved.
//

import UIKit

class TerceraViewController: UIViewController {
    
    var horarios: horarios!
    var pelicula: pelicula!
    
     @IBOutlet weak var foto: UIImageView!
     @IBOutlet weak var horas: UILabel!
    @IBOutlet weak var asientos: UILabel!
    @IBOutlet weak var comprados: UILabel!
    @IBOutlet weak var boletos: UILabel!
    @IBOutlet weak var precio: UILabel!
    
    @IBOutlet weak var nombre: UILabel!
    

    @IBAction func subeBaja(_ sender: UIStepper) {
    
    let total = Int(sender.value)
        comprados.text = String(total)
        
    let precio = Int(pelicula.precio)
        
    let compra = Int(sender.value) * Int(precio)
        boletos.text = "Total de Compra: $\(String(compra))"
        
   
    
    }
    
    
        override func viewDidLoad() {
        super.viewDidLoad()
        
        foto.image = UIImage(named: pelicula.foto)
        asientos.text = "Asientos Disponibles: \(horarios.asientos)"
        horas.text = "Precio: $\(pelicula.precio)"
            
        precio.text = "Hora: \(horarios.horas):00"
       
        nombre.text = pelicula.nombre
            
            self.view.backgroundColor = .black

    }
    

    @IBAction func cerrar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
   
    
    @IBAction func finalizar(_ sender: UIButton) {
        self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
        
        
        
        
        
    }
    
}
