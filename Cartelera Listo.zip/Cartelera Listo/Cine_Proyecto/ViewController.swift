//
//  ViewController.swift
//  Cine_Proyecto
//
//  Created by Diego Fonseca Medina  on 02/10/19.
//  Copyright © 2019 Diego Fonseca Medina . All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource,UICollectionViewDelegate {
    
    var peliculas : [pelicula] = [
        pelicula(nombre:"Eso", foto: "1", precio: 72, horarios: [horarios(horas: 10, asientos: 15), horarios(horas: 12, asientos: 23), horarios(horas: 14, asientos: 15),horarios(horas: 16, asientos: 23), horarios(horas: 18, asientos: 20),horarios(horas: 21, asientos: 23),horarios(horas: 22, asientos: 23)])
        ,pelicula(nombre:"Avengers",foto:"2", precio: 72, horarios: [horarios(horas: 10, asientos: 14), horarios(horas: 12, asientos: 23), horarios(horas: 14, asientos: 15),horarios(horas: 16, asientos: 23), horarios(horas: 18, asientos: 20),horarios(horas: 21, asientos: 23),horarios(horas: 22, asientos: 23)]),
         pelicula(nombre:"Superman", foto:"3", precio: 72, horarios: [horarios(horas: 10, asientos: 14), horarios(horas: 12, asientos: 23), horarios(horas: 14, asientos: 15),horarios(horas: 16, asientos: 23), horarios(horas: 18, asientos: 20),horarios(horas: 21, asientos: 23),horarios(horas: 22, asientos: 23)]),
         pelicula(nombre:"Joker", foto:"4", precio: 72, horarios: [horarios(horas: 10, asientos: 14), horarios(horas: 12, asientos: 23),horarios(horas: 14, asientos: 15),horarios(horas: 16, asientos: 23), horarios(horas: 18, asientos: 20),horarios(horas: 21, asientos: 23),horarios(horas: 22, asientos: 23)]),
         pelicula(nombre:"Spiderman", foto:"5", precio: 72, horarios: [horarios(horas: 10, asientos: 14), horarios(horas: 12, asientos: 23),horarios(horas: 14, asientos: 15),horarios(horas: 16, asientos: 23), horarios(horas: 18, asientos: 20),horarios(horas: 21, asientos: 23),horarios(horas: 22, asientos: 23)]),
         pelicula(nombre:"John Wick", foto:"6", precio: 72, horarios: [horarios(horas: 10, asientos: 14), horarios(horas: 12, asientos: 23),horarios(horas: 14, asientos: 15),horarios(horas: 16, asientos: 23), horarios(horas: 18, asientos: 20),horarios(horas: 21, asientos: 23),horarios(horas: 22, asientos: 23)])]
    
    
    
    @IBOutlet weak var tablita : UICollectionView?
    
    
        override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return peliculas.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell =
            collectionView.dequeueReusableCell(withReuseIdentifier: "cuadrito", for: indexPath) as!
                PeliculaCollectionViewCell
        
        
        cell.nombre.text = peliculas[indexPath.item].nombre
        cell.poster.image = UIImage(named: peliculas[indexPath.item].foto)
        
        
        self.view.backgroundColor = .black
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let segundaVista = segue.destination as! SegundaVistaViewController
        
        let myIndexPath = tablita?.indexPathsForSelectedItems
        
        segundaVista.pelicula = peliculas[(myIndexPath?.first?.item)!]

        
    }
    
    
}
