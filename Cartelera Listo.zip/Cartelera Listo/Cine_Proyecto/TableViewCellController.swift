//
//  TableViewCellController.swift
//  Cine_Proyecto
//
//  Created by Diego Fonseca Medina  on 08/10/19.
//  Copyright © 2019 Diego Fonseca Medina . All rights reserved.
//

import UIKit

class TableViewCellController: UITableViewCell {

   
    @IBOutlet weak var hora: UILabel!
    
    @IBOutlet weak var asientos: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
