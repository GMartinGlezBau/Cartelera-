//
//  pelis.swift
//  Cine_Proyecto
//
//  Created by Diego Fonseca Medina  on 07/10/19.
//  Copyright © 2019 Diego Fonseca Medina . All rights reserved.
//

import UIKit

struct pelicula {
    var nombre: String
    var foto: String
    var precio:  Int
    var horarios: [horarios]
}
