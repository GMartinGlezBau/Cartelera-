//
//  PeliculaCollectionViewCell.swift
//  Cine_Proyecto
//
//  Created by Diego Fonseca Medina  on 07/10/19.
//  Copyright © 2019 Diego Fonseca Medina . All rights reserved.
//

import UIKit

class PeliculaCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var poster: UIImageView!
    @IBOutlet weak var nombre: UILabel!
    
}
