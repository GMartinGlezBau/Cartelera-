//
//  hoarios.swift
//  Cine_Proyecto
//
//  Created by Diego Fonseca Medina  on 08/10/19.
//  Copyright © 2019 Diego Fonseca Medina . All rights reserved.
//

import UIKit

class horarios{
    
    var horas: Int
    var asientos: Int
    init(horas:Int, asientos: Int) {
        self.horas = horas
        self.asientos = asientos
        
    }
}


