//
//  SegundaVistaController.swift
//  Cine_Proyecto
//
//  Created by Diego Fonseca Medina  on 07/10/19.
//  Copyright © 2019 Diego Fonseca Medina . All rights reserved.
//

import UIKit

class SegundaVistaViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    
    @IBOutlet weak var horas: UILabel!
    
    @IBOutlet weak var asientos: UILabel!
    
    @IBAction func regresar(_ sender: Any) {
    }
    
    @IBOutlet weak var tablita1: UITableView?
    
    var pelicula: pelicula!
    @IBOutlet weak var foto: UIImageView!
    @IBOutlet weak var nombre: UILabel!
    @IBOutlet weak var precio: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        foto.image = UIImage(named: pelicula.foto)
        nombre.text = pelicula.nombre
        precio.text = "Precio: $\(pelicula.precio)"
        
        self.view.backgroundColor = .black
        
        
        
}
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pelicula.horarios.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! TableViewCellController
        cell.hora.text = "\(pelicula.horarios[indexPath.row].horas):00"
        cell.asientos.text = "Disponibles: \(pelicula.horarios[indexPath.row].asientos)"
        return cell
    }
    
    
    @IBAction func cerrar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let terceraVista = segue.destination as! TerceraViewController
        terceraVista.pelicula = pelicula
        
        let myIndexPath = tablita1?.indexPathForSelectedRow
        
        terceraVista.horarios = pelicula.horarios[(myIndexPath?.row)!]
           
    }
    
    
        
        
        
        
        
    
    
    
    
  
}
